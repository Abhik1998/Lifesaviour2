 

<!DOCTYPE html>
  <html>
  <head>
    <title>Your life Saviour</title>
    <style type="text/css">
      p{background-color: blue;
  } a:hover{background-color: green;}</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   </head>
  <body><section style="width: 100%; height: 100%;float: left; background-color: red"><div style="width: 25%; height: 100%;"></div>
    <div style="width: 50% ;height: 80%;"><font size="10px"><i class="fa fa-diamond" style="color: silver">LIFE SAVIOUR</i></font></div><div style="width: 100%; height: 100%;background-color: yellow"><i>-------"Your health our technology"</i></div>
    
  </section>
  <font color="white" size="6px" ><table style="float: left;" border="2px" width="270px" height="680px" bgcolor="#0000A0"><p><tr><td><i class="fa fa-home" style="color: white"></i><a href="projectspeech.html"><font color="white">Home</a></td></tr>
    <tr><td><i class="fa fa-heartbeat" style="color:red"></i><a href="accorgan.html"><font color="white">Organ Acceptor</a></td></tr>
    <tr><td><i class="fa fa-hospital-o" style="color: yellow"></i><a href="menuslove.html"><font color="white">Hospital login</a></td></tr>
    <tr><td><i class="fa fa-plus-square" style="color: red"></i><a href="donorpage.html"><font color="white">Organ Donor</a></td></tr>
  </table></font><form name="save" action="/action_page.php" onsubmit="return love()">
<table border="2px" style="border-radius: 2px ; border-style: groove; background-color: cyan" width="63%" height="600px" style="float: right;">
  <thead><p><font size="24px" color="white"><i class="fa fa-user-md" style="color: red"></i>Acceptor Details</font></p></thead>
  <tr><td><font size="5px">Name of Patient</font></td><td><input type="text" name="username"></td></tr>
  <tr><td><font size="5px">Phone Number</font></td><td><input type="tel" minlength="10" maxlength="10"     name="Number"></td></tr>
  <tr><td><font size="5px">Hospital Name</font></td><td><input type="text" name="txt_name" placeholder="where patient is admitted"></td></tr>
  <tr><td><font size="5px">Blood Group</font></td><td><input type="text" name="txt_name" placeholder="Which Group"></td></tr>
  <tr><td><font size="5px">Address</font></td><td><input type="text" name="txt_name" placeholder="lane"></td></tr>
  <tr><td><font size="5px">Aadhaar card no.</font></td><td><input type="text" name="txt_name" placeholder="654372628765"></td></tr>
<tr><td></td><td><input type="submit" value="Submit" ></td></tr></table></form>
<?php
$servername = "localhost:3306";
$username = "root";
$password = "abhik1998";
$dbname = "menus";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO MyGuests (Name, Address)
VALUES ('John', 'Doe')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?><script type="text/javascript">
function love(){var x=document.forms["save"]["username"];
if(x=="")
window.alert("Name must be filled up");
return false;
}
</script>
  




  </body>
  </html>